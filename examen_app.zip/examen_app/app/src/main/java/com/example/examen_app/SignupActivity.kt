package com.example.examen_app

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Patterns
import android.widget.TextView
import com.google.android.material.button.MaterialButton
import com.google.android.material.textfield.TextInputLayout

class SignupActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_signup)

        val layoutName = findViewById<TextInputLayout>(R.id.layoutName)
        val layoutEmail = findViewById<TextInputLayout>(R.id.layoutEmail)
        val layoutPassword = findViewById<TextInputLayout>(R.id.layoutPassword)
        val layoutConfirmPassword = findViewById<TextInputLayout>(R.id.layoutConfirmPassword)
        val buttonSignup = findViewById<MaterialButton>(R.id.buttonSignup)
        val buttonBack = findViewById<TextView>(R.id.buttonBack)

        buttonSignup.setOnClickListener {
            validateSignupForm(layoutName, layoutEmail, layoutPassword, layoutConfirmPassword)
        }

        buttonBack.setOnClickListener {
            finish()
        }
    }

    private fun validateSignupForm(
        layoutName: TextInputLayout,
        layoutEmail: TextInputLayout,
        layoutPass: TextInputLayout,
        layoutConfirmPass: TextInputLayout
    ): Boolean {

        val name = layoutName.editText?.text.toString().trim()
        val email = layoutEmail.editText?.text.toString().trim()
        val password = layoutPass.editText?.text.toString().trim()
        val confirmPassword = layoutConfirmPass.editText?.text.toString().trim()

        layoutName.error = null
        layoutEmail.error = null
        layoutPass.error = null
        layoutConfirmPass.error = null

        var isValid = true

        if (name.isEmpty()) {
            layoutName.error = "El nombre es requerido"
            isValid = false
        }

        if (email.isEmpty()) {
            layoutEmail.error = "El email es requerido"
            isValid = false
        } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches()) {
            layoutEmail.error = "Formato de email inválido"
            isValid = false
        }

        if (password.isEmpty()) {
            layoutPass.error = "La contraseña es requerida"
            isValid = false
        }

        if (confirmPassword.isEmpty()) {
            layoutConfirmPass.error = "La confirmación es requerida"
            isValid = false
        } else if (password != confirmPassword) {
            layoutConfirmPass.error = "Las contraseñas no coinciden"
            isValid = false
        }

        return isValid
    }
}